package com.example.plant;

import java.util.Objects;

public class Plant {
    private boolean cantGrowInWinter;
    private Soil[] compatibleSoil;
    private String name;
    private String preferedSeason;
    private String subGroup;
    private double weeksToGrow;

    public Plant(String name2, double daysToGrows, String subGroup2) {
        this.compatibleSoil = new Soil[0];
        this.name = name2;
        this.weeksToGrow = daysToGrows;
        this.subGroup = subGroup2;
        this.compatibleSoil = determineCompatibleSoil();
        this.cantGrowInWinter = noGrowInWinter();
        this.preferedSeason = determineSeason();
    }

    public Plant() {
        this.compatibleSoil = new Soil[0];
        this.name = "";
        this.weeksToGrow = 0.0d;
        this.subGroup = "";
        this.cantGrowInWinter = false;
        this.preferedSeason = "";
    }

    public void setName(String name2) {
        this.name = name2;
    }

    public void setWeeksToGrow(double weeksToGrow2) {
        this.weeksToGrow = weeksToGrow2;
    }

    public void setSubGroup(String subGroup2) {
        this.subGroup = subGroup2;
    }

    public void setCompatibleSoil(Soil[] compatibleSoil2) {
        this.compatibleSoil = compatibleSoil2;
    }

    public Soil[] getCompatibleSoil() {
        return this.compatibleSoil;
    }

    public double getWeeksToGrow() {
        return this.weeksToGrow;
    }

    public String getSubGroup() {
        return this.subGroup;
    }

    public String getName() {
        return this.name;
    }

    public boolean getCantGrowInWinter() {
        return this.cantGrowInWinter;
    }

    public String getPreferedSeason() {
        return this.preferedSeason;
    }

    public boolean noGrowInWinter() {
        return this.subGroup.equals("Tomato") || this.subGroup.equals("Herb");
    }

    public String determineSeason() {
        if (this.subGroup.equals("Leafy Greens") || this.subGroup.equals("Herb")) {
            return "Fall";
        }
        if (this.subGroup.equals("Roots")) {
            return "Summer";
        }
        return "Spring";
    }

    public Soil[] determineCompatibleSoil() {
        Soil[] list0 = new Soil[0];
        Soil[] list1 = {new Soil("Sand"), new Soil("Silt"), new Soil("Peaty")};
        Soil[] list2 = {new Soil("Silt"), new Soil("Chalky")};
        Soil[] list3 = {new Soil("Sand")};
        Soil[] list4 = {new Soil("Loam")};
        if (Objects.equals(this.subGroup, "Brassicas")) {
            return list4;
        }
        if (Objects.equals(this.subGroup, "Leafy Greens")) {
            return list2;
        }
        if (Objects.equals(this.subGroup, "Tomato")) {
            return list3;
        }
        if (Objects.equals(this.subGroup, "Herb")) {
            return list4;
        }
        if (Objects.equals(this.subGroup, "Root")) {
            return list1;
        }
        return list0;
    }

    public String toString() {
        return this.name;
    }
}

package com.example.plant;
public class Soil {
    private double growthFactor;
    private String name;

    public Soil(String name2) {
        this.name = name2;
        this.growthFactor = 1.0d;
    }

    public Soil() {
        this.name = "";
        this.growthFactor = 0.0d;
    }

    public double getGrowthFactor() {
        return this.growthFactor;
    }

    public void setGrowthFactor(double NewgrowthFactor) {
        this.growthFactor = NewgrowthFactor;
    }

    public String getName() {
        return this.name;
    }

    public void changeGrowthFactor(Plant plant) {
        double finalGrowthFactor = 1.0d;
        Soil[] plantSoil = plant.getCompatibleSoil();
        for (Soil name2 : plantSoil) {
            if (this.name.equals(name2.getName())) {
                finalGrowthFactor = 1.0d;
            } else {
                finalGrowthFactor = 1.7d;
            }
        }
        setGrowthFactor(finalGrowthFactor);
    }

    public String toString() {
        return this.name;
    }
}
